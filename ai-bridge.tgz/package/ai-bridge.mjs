#!/usr/bin/env node

// server/bridgeCli.ts
import { spawn as spawn2 } from "node:child_process";

// server/aiAccess.ts
import { timingSafeEqual } from "node:crypto";
var DEFAULT_ORIGINS = ["https://aakin21.github.io"];
function allowedOrigins(env) {
  const origins = (env.AI_ALLOWED_ORIGINS ?? "").split(",").map((o) => o.trim()).filter(Boolean);
  return new Set(origins.length > 0 ? origins : DEFAULT_ORIGINS);
}
function aiAccess(env, options = {}) {
  const password = env.AI_PASSWORD ?? "";
  const allowed = allowedOrigins(env);
  const allowedOrigin = (origin) => allowed.has(origin) || options.loopbackOrigins === true && isLoopbackOrigin(origin);
  return (req, res, next) => {
    if (!isApiPath(req.url)) return next();
    const origin = req.headers.origin;
    if (origin && allowedOrigin(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
      res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
      res.setHeader(
        "Access-Control-Allow-Headers",
        "Content-Type, x-ai-key, ngrok-skip-browser-warning"
      );
      res.setHeader("Access-Control-Expose-Headers", "x-ai-access");
    }
    if (req.method === "OPTIONS") {
      res.statusCode = 204;
      return res.end();
    }
    if (origin && !allowedOrigin(origin) && !sameOrigin(origin, req)) {
      return deny(res, 403, "requests from other sites are refused");
    }
    if (isLocal(req)) return next();
    if (!password) return deny(res, 503, "AI_PASSWORD is not set on the AI server");
    if (!matches(req.headers["x-ai-key"], password)) return deny(res, 401, "wrong AI password");
    next();
  };
}
function isLoopbackOrigin(origin) {
  try {
    const url = new URL(origin);
    return url.origin === origin && (url.protocol === "http:" || url.protocol === "https:") && (url.hostname === "localhost" || url.hostname === "127.0.0.1" || url.hostname === "[::1]");
  } catch {
    return false;
  }
}
function isApiPath(url) {
  if (!url) return false;
  const raw = url.toLowerCase();
  if (/\/api(\/|\\|%2f|%5c|$)/.test(raw)) return true;
  try {
    return new URL(url, "http://localhost").pathname.toLowerCase().startsWith("/api/");
  } catch {
    return true;
  }
}
function isLocal(req) {
  const host = (req.headers.host ?? "").replace(/:\d+$/, "");
  return host === "localhost" || host === "127.0.0.1" || host === "[::1]";
}
function sameOrigin(origin, req) {
  try {
    return new URL(origin).host === (req.headers.host ?? "").toLowerCase();
  } catch {
    return false;
  }
}
function matches(given, password) {
  if (typeof given !== "string") return false;
  const a = Buffer.from(given);
  const b = Buffer.from(password);
  return a.length === b.length && timingSafeEqual(a, b);
}
var DENIED_LINGER_MS = 1e3;
function deny(res, status, error) {
  res.statusCode = status;
  res.setHeader("x-ai-access", "denied");
  res.setHeader("Content-Type", "application/json");
  res.setHeader("Connection", "close");
  const socket = res.socket;
  res.end(JSON.stringify({ error }), () => {
    if (!socket) return;
    res.req?.resume();
    socket.end();
    setTimeout(() => socket.destroy(), DENIED_LINGER_MS).unref();
  });
}

// server/bridge.ts
import http from "node:http";
import { readFileSync } from "node:fs";
import { join as join4 } from "node:path";
import * as util from "node:util";

// src/ai/Models.ts
var CLAUDE_MODELS = ["haiku", "sonnet", "opus"];
var OPENROUTER_MODELS = [
  { id: "anthropic/claude-haiku-5.5", label: "Claude Haiku 5.5", company: "Anthropic" },
  { id: "anthropic/claude-sonnet-5.5", label: "Claude Sonnet 5.5", company: "Anthropic" },
  { id: "anthropic/claude-opus-5.5", label: "Claude Opus 5.5", company: "Anthropic" },
  { id: "google/gemini-3.8-flash", label: "Gemini 3.8 Flash", company: "Google" },
  { id: "google/gemini-4-argon", label: "Gemini 4 Argon", company: "Google" },
  { id: "openai/gpt-6-luna", label: "GPT-6 Luna", company: "OpenAI" },
  { id: "openai/gpt-6.1-sol", label: "GPT-6.1 Sol", company: "OpenAI" },
  { id: "x-ai/grok-4.7", label: "Grok 4.7", company: "xAI" },
  { id: "deepseek/deepseek-v4.1-flash", label: "DeepSeek V4.1 Flash", company: "DeepSeek" },
  { id: "deepseek/deepseek-v4-pro-0813", label: "DeepSeek V4 Pro", company: "DeepSeek" },
  { id: "qwen/qwen3.8-max-0902", label: "Qwen3.8 Max", company: "Qwen" },
  { id: "mistralai/mistral-large-4-0", label: "Mistral Large 4", company: "Mistral" }
];
var OPENROUTER_ID = /^[a-z0-9][a-z0-9._-]*\/[a-z0-9][a-z0-9._-]*(:[a-z0-9._-]+)?$/i;
function isOpenRouterId(id) {
  return id.length <= 100 && OPENROUTER_ID.test(id);
}
function openRouterId(model) {
  if (!model.startsWith("openrouter:")) return null;
  const id = model.slice("openrouter:".length);
  return isOpenRouterId(id) ? id : null;
}
var LOCAL_NAME = /^[a-z0-9][a-z0-9._:/-]*$/i;
function isLocalModelName(name) {
  return name.length <= 100 && LOCAL_NAME.test(name);
}
function localModelId(model) {
  if (!model.startsWith("local:")) return null;
  const name = model.slice("local:".length);
  return isLocalModelName(name) ? name : null;
}
function codexModel(model) {
  if (model === "codex") return { model: null };
  if (!model.startsWith("codex:")) return null;
  const name = model.slice("codex:".length);
  return isLocalModelName(name) ? { model: name } : null;
}
function geminiModelId(model) {
  if (!model.startsWith("gemini:")) return null;
  const name = model.slice("gemini:".length);
  return isLocalModelName(name) ? name : null;
}
var CLI_TOOL_NAME = /^[a-z][a-z0-9_]{0,31}$/;
function isCliToolName(name) {
  return CLI_TOOL_NAME.test(name);
}
function cliToolOf(model) {
  if (!model.startsWith("cli:")) return null;
  const name = model.slice("cli:".length);
  return isCliToolName(name) ? name : null;
}
function isLlmModel(model) {
  return typeof model === "string" && (CLAUDE_MODELS.includes(model) || openRouterId(model) !== null || localModelId(model) !== null || codexModel(model) !== null || geminiModelId(model) !== null || cliToolOf(model) !== null);
}
function modelLabel(model) {
  if (!model) return "";
  const local = localModelId(model);
  if (local !== null) return `${local} (Local)`;
  const codex = codexModel(model);
  if (codex !== null) return codex.model === null ? "Codex" : `${codex.model} (Codex)`;
  const gemini = geminiModelId(model);
  if (gemini !== null) return `${gemini} (Gemini)`;
  const tool = cliToolOf(model);
  if (tool !== null) return `${tool} (this computer)`;
  const id = openRouterId(model);
  if (id === null) return model[0].toUpperCase() + model.slice(1);
  const known = OPENROUTER_MODELS.find((m) => m.id === id);
  return `${known ? known.label : id} (OpenRouter)`;
}

// src/ai/Limits.ts
var DEFAULT_BRIDGE_PORT = 8642;
var LLM_SERVER_TIMEOUT_MS = 11e4;

// server/llmSession.ts
var SESSION_CLOSED = "the LLM session was closed";
var LlmError = class extends Error {
  constructor(message, retryable, fromResult = false) {
    super(message);
    this.retryable = retryable;
    this.fromResult = fromResult;
  }
};
function sessionClosed() {
  return new LlmError(SESSION_CLOSED, true);
}
var num = (v) => typeof v === "number" && Number.isFinite(v) ? v : null;
var errorText = (err) => err instanceof Error ? err.message : String(err);

// server/claudeSession.ts
var MODEL_IDS = {
  haiku: "claude-haiku-5-5",
  sonnet: "claude-sonnet-5-5",
  opus: "claude-opus-5-5"
};
var LASTING = [
  /hit your .*limit/i,
  // "You've hit your session limit · resets 3:45pm", weekly, Opus, spend
  /spend limit|credits? required|budget/i,
  /\b40[13]\b|authenticat|not logged in|login expired|invalid api key|\/login/i
];
function lastingError(text) {
  return LASTING.some((re) => re.test(text));
}
var ClaudeSession = class {
  constructor(query, matchId, model, systemPrompt, maxBudgetUsd, side = "") {
    this.matchId = matchId;
    this.model = model;
    this.side = side;
    this.queue = [];
    this.wake = null;
    this.closed = false;
    this.ended = false;
    // the SDK stream finished or failed: no answer will come any more
    this.waiting = [];
    this.costSoFar = 0;
    this.apiMsSoFar = 0;
    this.q = query({
      prompt: this.input(),
      options: {
        model: MODEL_IDS[model],
        systemPrompt,
        tools: [],
        settingSources: [],
        persistSession: false,
        maxBudgetUsd,
        env: { ...process.env, CLAUDE_CODE_DISABLE_AUTO_MEMORY: "1" }
      }
    });
    void this.readLoop();
  }
  async *input() {
    while (!this.closed) {
      const next = this.queue.shift();
      if (next) {
        yield next;
        continue;
      }
      await new Promise((r) => this.wake = r);
    }
  }
  async readLoop() {
    let reason = new Error("the LLM session ended");
    try {
      for await (const message of this.q) {
        if (message.type === "system" && message.subtype === "init")
          console.warn(
            `[llm] ${this.side} session started: ${this.model} (${MODEL_IDS[this.model]}) \u2192 ${message.model}`
          );
        if (message.type === "system" && message.subtype === "api_retry")
          console.warn(
            `[llm] ${this.side} (${this.model}) retry ${message.attempt}/${message.max_retries} in ${Math.round(message.retry_delay_ms / 1e3)} s: status ${message.error_status ?? "none"}, ${String(message.error)}${message.no_response ? `, no response after ${Math.round(message.no_response.waited_ms / 1e3)} s` : ""}`
          );
        if (message.type !== "result") continue;
        const pending = this.waiting.shift();
        const meta = this.meta(message);
        if (!pending) continue;
        if (message.subtype === "success" && !message.is_error) {
          pending.resolve({ text: message.result, meta });
          continue;
        }
        const text = message.subtype === "success" ? message.result || "LLM API error" : [`LLM error: ${message.subtype}`, ...message.errors ?? []].join("; ");
        const lasting = message.subtype === "error_max_budget_usd" || lastingError(text);
        pending.reject(new LlmError(text, !lasting, true));
      }
    } catch (err) {
      reason = err;
    }
    this.ended = true;
    for (const p of this.waiting.splice(0)) p.reject(reason);
  }
  meta(message) {
    const total = num(message.total_cost_usd);
    const costUsd = total === null || total < this.costSoFar ? null : total - this.costSoFar;
    if (total !== null && total > this.costSoFar) this.costSoFar = total;
    const usage = message.usage ?? {};
    return {
      costUsd,
      inputTokens: num(usage.input_tokens),
      outputTokens: num(usage.output_tokens),
      cacheReadTokens: num(usage.cache_read_input_tokens),
      cacheWriteTokens: num(usage.cache_creation_input_tokens),
      apiMs: this.apiDelta(num(message.duration_api_ms)),
      turns: num(message.num_turns),
      modelIds: Object.keys(message.modelUsage ?? {})
    };
  }
  // duration_api_ms is the session's running total; one answer's share is the difference
  apiDelta(total) {
    if (total === null || total < this.apiMsSoFar) return null;
    const delta = total - this.apiMsSoFar;
    this.apiMsSoFar = total;
    return delta;
  }
  // A session that can still answer; otherwise the next request opens a new one
  isAlive() {
    return !this.closed && !this.ended;
  }
  ask(prompt) {
    return new Promise((resolve3, reject) => {
      if (!this.isAlive()) return reject(new LlmError("the LLM session ended", true));
      this.waiting.push({ resolve: resolve3, reject });
      this.queue.push({
        type: "user",
        message: { role: "user", content: prompt },
        parent_tool_use_id: null
      });
      this.wake?.();
      this.wake = null;
    });
  }
  // Replaced by a new match or model, or failed: requests still waiting get an error now
  close() {
    this.closed = true;
    this.wake?.();
    this.q.close();
    for (const p of this.waiting.splice(0)) p.reject(sessionClosed());
  }
};

// server/chatSession.ts
var MAX_DETAIL = 300;
var capped = (text) => text.length > MAX_DETAIL ? `${text.slice(0, MAX_DETAIL)}\u2026` : text;
var DEV_SERVER = "the dev server";
function keyProblem(name, key, server) {
  return /^[\x21-\x7e]*$/.test(key) ? null : `${name} has characters a header cannot carry (a line break or a pasted quote?); fix it in .env.local and restart ${server}.`;
}
var OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
var setOpenRouterKey = (server) => `Set OPENROUTER_API_KEY in .env.local and restart ${server}.`;
function openRouterProvider(key, maxBudgetUsd, server = DEV_SERVER) {
  const k = key.trim();
  if (!k) return setOpenRouterKey(server);
  const problem = keyProblem("OPENROUTER_API_KEY", k, server);
  if (problem) return problem;
  return (id) => ({
    id,
    service: "OpenRouter",
    started: "OpenRouter",
    url: OPENROUTER_URL,
    key: k,
    headers: {
      "HTTP-Referer": "https://aakin21.github.io/2D-Battle-Simulation/",
      "X-Title": "2D Battle Simulation"
    },
    body: { usage: { include: true } },
    historyTurns: Infinity,
    maxBudgetUsd,
    checkAnswer: false,
    // fetch's own text: with the key checked no header can be in it, and the key is masked anyway
    unreachable: (err) => `OpenRouter could not be reached: ${capped(errorText(err).split(k).join("\u2026"))}`,
    redirected: (status) => `OpenRouter answered with a redirect (HTTP ${status}), which is not followed.`,
    hint: (status) => status === 401 ? ` ${setOpenRouterKey(server)}` : ""
  });
}
var DEFAULT_LOCAL_URL = "http://localhost:11434/v1";
var DEFAULT_HISTORY_TURNS = 3;
var CHAT_PATH = "/chat/completions";
function isLoopback(host) {
  return host === "localhost" || host.endsWith(".localhost") || host === "[::1]" || /^127\.\d+\.\d+\.\d+$/.test(host);
}
var MODEL_MISSING = /model.*(not found|does not exist)|no such model/i;
function localServer(url, server = DEV_SERVER) {
  let u = null;
  try {
    u = new URL((url ?? "").trim() || DEFAULT_LOCAL_URL);
  } catch {
  }
  if (!u || u.protocol !== "http:" && u.protocol !== "https:")
    return `LOCAL_LLM_URL in .env.local must be an http:// or https:// address (Ollama: http://localhost:11434/v1); restart ${server} after changing it.`;
  if (u.username || u.password)
    return `LOCAL_LLM_URL in .env.local must not contain a user name or password: put a key in LOCAL_LLM_KEY and restart ${server}.`;
  const path = u.pathname.replace(/\/+$/, "");
  const base = u.origin + path;
  const chat = path.endsWith(CHAT_PATH);
  u.pathname = chat ? path : path + CHAT_PATH;
  const chatUrl = u.href;
  u.pathname = (chat ? path.slice(0, -CHAT_PATH.length) : path) + "/models";
  return {
    origin: u.origin,
    base,
    chatUrl,
    modelsUrl: u.href,
    insecureRemote: u.protocol === "http:" && !isLoopback(u.hostname)
  };
}
function localProvider(url, key, turns, maxBudgetUsd, server = DEV_SERVER) {
  const t = (turns ?? "").trim();
  const historyTurns = /^\d+$/.test(t) ? Number(t) : DEFAULT_HISTORY_TURNS;
  if (t && !/^\d+$/.test(t))
    console.warn(
      `[llm] LOCAL_LLM_HISTORY_TURNS in .env.local must be a whole number (0 or more); ${DEFAULT_HISTORY_TURNS} is used.`
    );
  const where = localServer(url, server);
  if (typeof where === "string") return where;
  const k = key.trim();
  const problem = keyProblem("LOCAL_LLM_KEY", k, server);
  if (problem) return problem;
  const { base, chatUrl } = where;
  if (k && where.insecureRemote)
    console.warn(
      `[llm] LOCAL_LLM_KEY goes to ${base} unencrypted (http://); use https:// for a server on another computer.`
    );
  const label = `last ${historyTurns} turn${historyTurns === 1 ? "" : "s"}`;
  return (name) => ({
    id: name,
    service: "Local LLM",
    started: `local, ${base}, ${label}`,
    url: chatUrl,
    key: k,
    headers: {},
    body: { stream: false },
    historyTurns,
    maxBudgetUsd,
    checkAnswer: true,
    unreachable: (err) => {
      const code = err?.cause?.code;
      return `Local LLM could not be reached at ${base}${typeof code === "string" ? ` (${code})` : ""}: is Ollama (or your local server) running? Set LOCAL_LLM_URL in .env.local.`;
    },
    redirected: (status) => `Local LLM: the server at ${base} answered with a redirect (HTTP ${status}); set LOCAL_LLM_URL to the final address.`,
    hint: (status, detail) => {
      if (status === 401 || status === 403)
        return ` Set LOCAL_LLM_KEY in .env.local to the key the server expects and restart ${server}.`;
      if (status === 404 || MODEL_MISSING.test(detail))
        return ` The server at ${base} does not know the model "${name}" (with Ollama: ollama pull ${name}), or LOCAL_LLM_URL is not its OpenAI-compatible address (Ollama's ends in /v1).`;
      return "";
    }
  });
}
var THINK_CLOSE = /<\/think(?:ing)?\s*>/gi;
var THINK_OPEN = /<think(?:ing)?(?:\s[^<>]*)?>/i;
function withoutThinking(text) {
  let end = -1;
  for (const m of text.matchAll(THINK_CLOSE)) end = m.index + m[0].length;
  if (end < 0) return text.replace(THINK_OPEN, "");
  const rest = text.slice(end);
  return rest.includes("{") ? rest.trimStart() : text;
}
var MAX_ANSWER_CHARS = 2e5;
function localAnswer(service, content, finishReason) {
  const raw = typeof content === "string" ? content : Array.isArray(content) ? content.filter((p) => p?.type === "text" && typeof p.text === "string").map((p) => p.text).join("") : null;
  if (raw === null) return null;
  const text = withoutThinking(raw);
  if (!text.trim())
    throw new LlmError(
      `${service}: the answer was empty; a reasoning model may have used its whole output on thinking.`,
      true,
      true
    );
  if (finishReason === "length")
    throw new LlmError(
      `${service}: the answer was cut off at the model's output limit; raise the server's output or context limit.`,
      true,
      true
    );
  if (text.length > MAX_ANSWER_CHARS)
    throw new LlmError(
      `${service}: the answer was ${Math.round(text.length / 1e3)} KB of text, more than the ${MAX_ANSWER_CHARS / 1e3} KB an answer may have.`,
      true,
      true
    );
  return text;
}
var ChatSession = class {
  constructor(matchId, model, systemPrompt, api, side = "") {
    this.matchId = matchId;
    this.model = model;
    this.systemPrompt = systemPrompt;
    this.api = api;
    this.turns = [];
    this.closed = false;
    this.queue = Promise.resolve();
    this.costSoFar = 0;
    this.abort = new AbortController();
    console.warn(`[llm] ${side} session started: ${api.id} (${api.started})`);
  }
  isAlive() {
    return !this.closed;
  }
  ask(prompt) {
    const answer = this.queue.then(() => this.send(prompt));
    this.queue = answer.catch(() => void 0);
    return answer;
  }
  async send(prompt) {
    const { api } = this;
    if (this.closed) throw sessionClosed();
    if (this.costSoFar >= api.maxBudgetUsd)
      throw new LlmError(
        `this session spent its budget of $${api.maxBudgetUsd} (LLM_MAX_BUDGET_USD)`,
        false,
        true
      );
    const messages = [
      { role: "system", content: this.systemPrompt }
    ];
    for (const [report2, answer] of this.turns)
      messages.push({ role: "user", content: report2 }, { role: "assistant", content: answer });
    messages.push({ role: "user", content: prompt });
    const started = Date.now();
    let res;
    try {
      res = await fetch(api.url, {
        method: "POST",
        signal: this.abort.signal,
        // Not followed: the rulebook and the report would go to whatever address it names
        redirect: "manual",
        headers: {
          ...api.key ? { Authorization: `Bearer ${api.key}` } : {},
          "Content-Type": "application/json",
          ...api.headers
        },
        body: JSON.stringify({ model: api.id, messages, ...api.body })
      });
    } catch (err) {
      throw new LlmError(this.closed ? SESSION_CLOSED : api.unreachable(err), true, true);
    }
    if (res.type === "opaqueredirect" || res.status >= 300 && res.status < 400) {
      res.body?.cancel().catch(() => void 0);
      throw new LlmError(api.redirected(res.status), false, true);
    }
    const body = await res.json().catch(() => null);
    if (this.closed) throw new LlmError(SESSION_CLOSED, true, true);
    const error = body?.error;
    const detail = capped(
      typeof error === "string" ? error : typeof error?.message === "string" ? error.message : ""
    );
    if (!res.ok) {
      const lasting = [400, 401, 402, 403, 404].includes(res.status);
      throw new LlmError(
        `${api.service}: ${detail || `HTTP ${res.status}`} (HTTP ${res.status}).${api.hint(res.status, detail)}`,
        !lasting,
        true
      );
    }
    const choice = body?.choices?.[0];
    const content = choice?.message?.content;
    const text = api.checkAnswer ? localAnswer(api.service, content, choice?.finish_reason) : content;
    if (typeof text !== "string")
      throw new LlmError(
        `${api.service}: the answer had no text${detail ? ` (${detail})` : ""}`,
        true,
        true
      );
    this.turns.push([prompt, text]);
    if (this.turns.length > api.historyTurns) this.turns.shift();
    const usage = body?.usage ?? {};
    const costUsd = num(usage.cost);
    if (costUsd !== null) this.costSoFar += costUsd;
    return {
      text,
      meta: {
        costUsd,
        inputTokens: num(usage.prompt_tokens),
        // cached input included, unlike the SDK's count
        outputTokens: num(usage.completion_tokens),
        cacheReadTokens: num(usage.prompt_tokens_details?.cached_tokens),
        cacheWriteTokens: null,
        apiMs: Date.now() - started,
        turns: 1,
        modelIds: [typeof body?.model === "string" ? body.model : api.id]
      }
    };
  }
  close() {
    this.closed = true;
    this.abort.abort();
  }
};

// server/cliTools.ts
import { accessSync, constants, statSync } from "node:fs";
import { delimiter, isAbsolute, join, resolve } from "node:path";
function splitCommand(text) {
  const words = [];
  let word = "";
  let inWord = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === "'") {
      const end = text.indexOf("'", i + 1);
      if (end < 0) return "a quote is not closed";
      word += text.slice(i + 1, end);
      inWord = true;
      i = end;
    } else if (c === '"') {
      let closed = false;
      for (i++; i < text.length; i++) {
        const d = text[i];
        if (d === '"') {
          closed = true;
          break;
        }
        if (d === "\\" && (text[i + 1] === '"' || text[i + 1] === "\\")) word += text[++i];
        else word += d;
      }
      if (!closed) return "a quote is not closed";
      inWord = true;
    } else if (c === "\\" && /[\s'"\\]/.test(text[i + 1] ?? "")) {
      word += text[++i];
      inWord = true;
    } else if (/\s/.test(c)) {
      if (inWord) words.push(word);
      word = "";
      inWord = false;
    } else {
      word += c;
      inWord = true;
    }
  }
  if (inWord) words.push(word);
  return words.length > 0 ? words : "it is empty";
}
var DEFAULT_HISTORY_TURNS2 = 3;
var OFF = /^(off|0|false|no)$/i;
var ON = /^(on|1|true|yes)?$/i;
function cliEnabled(value) {
  return !OFF.test((value ?? "").trim());
}
function cliConfig(vars, cwd = process.cwd()) {
  const warnings = [];
  const switchValue = (vars.CLI_TOOLS ?? "").trim();
  if (!OFF.test(switchValue) && !ON.test(switchValue))
    warnings.push("CLI_TOOLS must be on or off; command-line tools stay on.");
  const t = (vars.CLI_HISTORY_TURNS ?? "").trim();
  if (t && !/^\d+$/.test(t))
    warnings.push(
      `CLI_HISTORY_TURNS must be a whole number (0 or more); ${DEFAULT_HISTORY_TURNS2} is used.`
    );
  const tools = /* @__PURE__ */ new Map();
  for (const key of Object.keys(vars).sort()) {
    const value = vars[key];
    const match = /^CLI_TOOL_([A-Z0-9_]+)$/.exec(key);
    if (value === void 0 || !match) continue;
    const name = match[1].toLowerCase();
    if (!isCliToolName(name)) {
      warnings.push(
        `${key}: a tool's name starts with a letter and has at most 32 characters; left out.`
      );
      continue;
    }
    const argv = splitCommand(value);
    if (typeof argv === "string") {
      warnings.push(`${key} cannot be read (${argv}); left out.`);
      continue;
    }
    const exe = argv[0];
    tools.set(name, {
      name,
      label: modelLabel(`cli:${name}`),
      argv,
      path: exe.includes("/") || exe.includes("\\") ? resolve(cwd, exe) : null
    });
  }
  return {
    enabled: cliEnabled(vars.CLI_TOOLS),
    historyTurns: /^\d+$/.test(t) ? Number(t) : DEFAULT_HISTORY_TURNS2,
    tools,
    pathEnv: vars.PATH ?? "",
    vars,
    warnings
  };
}
var WINDOWS = process.platform === "win32";
function runnable(file) {
  try {
    if (!statSync(file).isFile()) return "no";
    accessSync(file, constants.X_OK);
    return "yes";
  } catch (err) {
    return err.code === "ENOENT" ? "missing" : "no";
  }
}
function locate(executable, path, pathEnv) {
  if (path !== null) {
    const r = runnable(path);
    return r === "yes" ? path : { problem: r === "missing" ? "missing" : "not runnable" };
  }
  const names = WINDOWS && !/\.(exe|com)$/i.test(executable) ? [`${executable}.exe`, `${executable}.com`] : [executable];
  let seen = false;
  for (const dir of pathEnv.split(delimiter)) {
    if (!dir || !isAbsolute(dir)) continue;
    for (const name of names) {
      const r = runnable(join(dir, name));
      if (r === "yes") return join(dir, name);
      if (r === "no") seen = true;
    }
  }
  return { problem: seen ? "not runnable" : "missing" };
}
function cliStatus(config) {
  if (!config.enabled) return [];
  return [...config.tools.values()].map((tool) => ({
    id: `cli:${tool.name}`,
    label: tool.label,
    available: typeof locate(tool.argv[0], tool.path, config.pathEnv) === "string"
  }));
}
var PASSED_ON = [
  "HOME",
  "USER",
  "LOGNAME",
  "SHELL",
  "TMPDIR",
  "TMP",
  "TEMP",
  "LANG",
  "LANGUAGE",
  "LC_ALL",
  "LC_CTYPE",
  "LC_MESSAGES",
  "TZ",
  "XDG_CONFIG_HOME",
  "XDG_DATA_HOME",
  "XDG_STATE_HOME",
  "XDG_CACHE_HOME",
  "XDG_RUNTIME_DIR",
  "HTTPS_PROXY",
  "HTTP_PROXY",
  "ALL_PROXY",
  "NO_PROXY",
  "https_proxy",
  "http_proxy",
  "all_proxy",
  "no_proxy",
  "NODE_EXTRA_CA_CERTS",
  "SSL_CERT_FILE",
  "SSL_CERT_DIR",
  "SYSTEMROOT",
  "WINDIR",
  "PATHEXT",
  "APPDATA",
  "LOCALAPPDATA",
  "USERPROFILE",
  "HOMEDRIVE",
  "HOMEPATH",
  "PROGRAMDATA"
];
function passedOnEnv(vars, pathEnv, extra = []) {
  const env = {};
  for (const name of [...PASSED_ON, ...extra]) {
    const value = vars[name];
    if (value !== void 0) env[name] = value;
  }
  env.PATH = pathEnv;
  env.NO_COLOR = "1";
  return env;
}
var ANSI = /\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)?|\x1b[@-Z\\-_]/g;
var withoutAnsi = (text) => text.replace(ANSI, "");
var plainText = (text) => withoutAnsi(text).replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, "");
var FLAGS_REFUSED = /unknown option|unknown argument|unexpected argument|unrecognized (?:option|argument)/i;
var oneLine = (text) => plainText(text).replace(/\s+/g, " ").trim();

// server/cliSession.ts
import { spawn, spawnSync } from "node:child_process";
import { mkdirSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join as join2 } from "node:path";
var MAX_STDOUT_BYTES = 4e6;
var MAX_STDERR_CHARS = 64e3;
var KILL_GRACE_MS = 1500;
var CLOSING = "Answer the new report.";
function cliPrompt(rulebook, turns, report2) {
  const parts = ["=== RULES ===", rulebook, ""];
  if (turns.length > 0) {
    parts.push(
      `=== EARLIER REPORTS AND YOUR ANSWERS (the last ${turns.length}, oldest first) ===`,
      ""
    );
    turns.forEach(
      ([r, a], i) => parts.push(
        `=== EARLIER REPORT ${i + 1} ===`,
        r,
        "",
        `=== YOUR ANSWER TO EARLIER REPORT ${i + 1} ===`,
        a,
        ""
      )
    );
  }
  parts.push("=== NEW REPORT ===", report2, "", CLOSING);
  return parts.join("\n") + "\n";
}
var WINDOWS2 = process.platform === "win32";
function signalTree(child, signal) {
  if (child.pid === void 0) return;
  if (WINDOWS2) {
    spawnSync("taskkill", ["/pid", String(child.pid), "/T", "/F"], { windowsHide: true });
    return;
  }
  try {
    process.kill(-child.pid, signal);
  } catch {
  }
}
function stopTree(child) {
  signalTree(child, "SIGTERM");
  setTimeout(() => signalTree(child, "SIGKILL"), KILL_GRACE_MS);
}
function runProcess(spec, started = () => void 0) {
  return new Promise((resolve3) => {
    const out = {
      code: null,
      signal: null,
      stdout: "",
      stderr: "",
      overflow: false,
      timedOut: false,
      spawnError: null
    };
    let child;
    try {
      child = spawn(spec.exe, spec.args, {
        cwd: spec.cwd,
        env: spec.env,
        stdio: ["pipe", "pipe", "pipe"],
        detached: !WINDOWS2,
        // the leader of its own process group, so the whole group can be stopped
        windowsHide: true,
        shell: false
      });
    } catch (err) {
      out.spawnError = String(err.code ?? "error");
      return resolve3(out);
    }
    started(child);
    const chunks = [];
    let bytes = 0;
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      started(null);
      out.stdout = Buffer.concat(chunks).toString("utf8");
      resolve3(out);
    };
    const timer = setTimeout(() => {
      out.timedOut = true;
      stopTree(child);
    }, spec.timeoutMs);
    child.stdout.on("data", (data) => {
      if (out.overflow) return;
      bytes += data.length;
      if (bytes > MAX_STDOUT_BYTES) {
        out.overflow = true;
        stopTree(child);
      } else chunks.push(data);
    });
    child.stderr.setEncoding("utf8");
    child.stderr.on("data", (text) => {
      out.stderr = (out.stderr + text).slice(-MAX_STDERR_CHARS);
    });
    child.on("error", (err) => {
      out.spawnError = err.code ?? "error";
      finish();
    });
    child.on("exit", (code, signal) => {
      out.code = code;
      out.signal = signal;
      if (!WINDOWS2) signalTree(child, "SIGKILL");
    });
    child.on("close", finish);
    child.stdin.on("error", () => void 0);
    child.stdin.end(spec.input);
  });
}
function lastWords(out) {
  const text = oneLine(out.stderr.trim() ? out.stderr : out.stdout);
  return text.length > MAX_DETAIL ? `\u2026${text.slice(-MAX_DETAIL)}` : text;
}
var CliSession = class {
  constructor(matchId, model, rulebook, tool, config, side = "", timeoutMs = LLM_SERVER_TIMEOUT_MS) {
    this.matchId = matchId;
    this.model = model;
    this.rulebook = rulebook;
    this.tool = tool;
    this.config = config;
    this.side = side;
    this.timeoutMs = timeoutMs;
    this.turns = [];
    this.closed = false;
    this.queue = Promise.resolve();
    this.dir = null;
    // the session's folder: dir/work is the tool's working folder
    this.running = null;
    const turns = config.historyTurns;
    console.warn(
      `[llm] ${side} session started: ${model} (a process per report, last ${turns} turn${turns === 1 ? "" : "s"})`
    );
  }
  isAlive() {
    return !this.closed;
  }
  ask(prompt) {
    const answer = this.queue.then(() => this.request(prompt));
    this.queue = answer.catch(() => void 0);
    return answer;
  }
  // The session's folder, made at the first request: the tool works in its empty "work" folder
  folder() {
    if (this.dir) return this.dir;
    const dir = mkdtempSync(join2(tmpdir(), "battle-cli-"));
    mkdirSync(join2(dir, "work"));
    this.dir = dir;
    return dir;
  }
  removeFolder() {
    if (!this.dir) return;
    try {
      rmSync(this.dir, { recursive: true, force: true });
      this.dir = null;
    } catch {
    }
  }
  async request(prompt) {
    const { tool, config } = this;
    const label = tool.label;
    const NAME = tool.name.toUpperCase();
    if (this.closed) throw sessionClosed();
    const notFound = `${label}: the command of CLI_TOOL_${NAME} was not found on this computer. Install it or fix the setting, then start the match again.`;
    const notRunnable = `${label}: the command of CLI_TOOL_${NAME} is not a file this user may run. Fix it and start the match again.`;
    const exe = locate(tool.argv[0], tool.path, config.pathEnv);
    if (typeof exe !== "string")
      throw new LlmError(exe.problem === "missing" ? notFound : notRunnable, false, true);
    const work = join2(this.folder(), "work");
    const input = cliPrompt(this.rulebook, this.turns, prompt);
    const started = Date.now();
    const out = await runProcess(
      {
        exe,
        args: tool.argv.slice(1),
        env: passedOnEnv(config.vars, config.pathEnv),
        cwd: work,
        input,
        timeoutMs: this.timeoutMs
      },
      (child) => this.running = child
    );
    const ms = Date.now() - started;
    if (this.closed) this.removeFolder();
    console.warn(
      `[llm] ${this.side} (${this.model}): ${exe} ran ${(ms / 1e3).toFixed(1)} s, start-up included (${out.spawnError ? `not started: ${out.spawnError}` : out.signal ? `ended by ${out.signal}` : `exit ${out.code}`})`
    );
    if (out.spawnError === "ENOENT") throw new LlmError(notFound, false, true);
    if (out.spawnError === "EACCES") throw new LlmError(notRunnable, false, true);
    if (out.spawnError)
      throw new LlmError(`${label} could not be started (${out.spawnError}).`, true, true);
    if (this.closed) throw new LlmError(SESSION_CLOSED, true, true);
    if (out.timedOut)
      throw new LlmError(
        `${label} did not answer within ${Math.round(this.timeoutMs / 1e3)} s; its process was stopped.`,
        true
      );
    if (out.overflow)
      throw new LlmError(
        `${label} wrote more than ${MAX_STDOUT_BYTES / 1e6} MB of output; its process was stopped.`,
        true,
        true
      );
    if (out.code !== 0 || out.signal !== null) {
      const detail = lastWords(out) || (out.signal ? `ended by ${out.signal}` : `exit ${out.code}`);
      if (FLAGS_REFUSED.test(detail))
        throw new LlmError(
          `${label} did not accept its command line (CLI_TOOL_${NAME}): ${detail}`,
          false,
          true
        );
      throw new LlmError(
        `${label} failed (${out.signal ? `ended by ${out.signal}` : `exit ${out.code}`}): ${detail}`,
        true,
        true
      );
    }
    const text = withoutThinking(withoutAnsi(out.stdout));
    if (!text.trim()) throw new LlmError(`${label}: the answer was empty.`, true, true);
    if (text.length > MAX_ANSWER_CHARS)
      throw new LlmError(
        `${label}: the answer was ${Math.round(text.length / 1e3)} KB of text, more than the ${MAX_ANSWER_CHARS / 1e3} KB an answer may have.`,
        true,
        true
      );
    this.turns.push([prompt, text]);
    if (this.turns.length > config.historyTurns) this.turns.shift();
    return {
      text,
      meta: {
        costUsd: null,
        inputTokens: null,
        outputTokens: null,
        cacheReadTokens: null,
        cacheWriteTokens: null,
        apiMs: null,
        turns: 1,
        modelIds: []
      }
    };
  }
  // Replaced by a new match or model, or the server is closing: a running tool is stopped and the
  // session's folder removed; a request still waiting fails with "session was closed"
  close() {
    this.closed = true;
    if (this.running) stopTree(this.running);
    this.removeFolder();
  }
};

// server/codexSession.ts
import { mkdirSync as mkdirSync2, mkdtempSync as mkdtempSync2, rmSync as rmSync2, writeFileSync } from "node:fs";
import { tmpdir as tmpdir2 } from "node:os";
import { join as join3, resolve as resolve2 } from "node:path";
var RULEBOOK_FILE = "rulebook.md";
function codexArgs(dir, model, threadId) {
  const config = [
    `model_instructions_file=${JSON.stringify(join3(dir, RULEBOOK_FILE))}`,
    "features.shell_tool=false",
    "features.view_image=false",
    "features.apps=false",
    "features.multi_agent=false",
    "features.remote_plugin=false",
    "features.hooks=false",
    "skills.bundled.enabled=false",
    "mcp_servers={}",
    'web_search="disabled"',
    'approval_policy="never"',
    "sandbox_workspace_write.network_access=false"
  ];
  return [
    "exec",
    "--json",
    ...config.flatMap((c) => ["--config", c]),
    ...model === null ? [] : ["--model", model],
    "--sandbox",
    "read-only",
    "--cd",
    join3(dir, "work"),
    "--skip-git-repo-check",
    "--ignore-user-config",
    "--ignore-rules",
    ...threadId === null ? [] : ["resume", threadId],
    "-"
  ];
}
var WINDOWS3 = process.platform === "win32";
var INSTALL = "npm install -g @openai/codex";
var WINDOWS_NOTE = WINDOWS3 ? " On Windows only a codex.exe is started (not npm's codex.cmd): use OpenAI's standalone installer, or set CODEX_PATH to a codex.exe." : "";
var codexMissing = (server) => `Codex is not installed on this computer (codex not found on PATH). Install it (${INSTALL}), run codex once and sign in, then restart ${server}.${WINDOWS_NOTE}`;
function codexRunner(vars, server, cwd = process.cwd()) {
  const pathEnv = vars.PATH ?? "";
  const codexKey = (vars.CODEX_API_KEY ?? "").trim();
  const openaiKey = (vars.OPENAI_API_KEY ?? "").trim();
  const problem = keyProblem("CODEX_API_KEY", codexKey, server) || keyProblem("OPENAI_API_KEY", openaiKey, server);
  if (problem) return problem;
  const configured = (vars.CODEX_PATH ?? "").trim();
  const found = locate("codex", configured ? resolve2(cwd, configured) : null, pathEnv);
  if (typeof found !== "string") {
    if (configured)
      return `CODEX_PATH is not the Codex program (no file this user may run there); fix it and restart ${server}.`;
    if (found.problem === "not runnable")
      return `codex on PATH is not a file this user may run; fix it (or set CODEX_PATH) and restart ${server}.`;
    return codexMissing(server);
  }
  const env = passedOnEnv(vars, pathEnv, [
    "CODEX_HOME",
    "CODEX_SQLITE_HOME",
    "CODEX_CA_CERTIFICATE"
  ]);
  if (codexKey) env.CODEX_API_KEY = codexKey;
  if (openaiKey) env.OPENAI_API_KEY = openaiKey;
  return { exe: found, env, keys: [codexKey, openaiKey].filter(Boolean), server };
}
var SESSION_ID = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
function readEvents(stdout) {
  const turn = {
    threadId: null,
    text: null,
    completed: false,
    usage: null,
    failed: null,
    lastError: null
  };
  for (const line of stdout.split("\n")) {
    if (!line.trim()) continue;
    let event;
    try {
      event = JSON.parse(line);
    } catch {
      continue;
    }
    if (!event || typeof event !== "object") continue;
    const item = event.item;
    switch (event.type) {
      case "thread.started":
        if (typeof event.thread_id === "string" && SESSION_ID.test(event.thread_id))
          turn.threadId = event.thread_id;
        break;
      case "item.completed":
        if (item?.type === "agent_message" && typeof item.text === "string") turn.text = item.text;
        break;
      case "turn.completed":
        turn.completed = true;
        turn.usage = event.usage && typeof event.usage === "object" ? event.usage : null;
        break;
      case "turn.failed": {
        const message = event.error?.message;
        turn.failed = typeof message === "string" && message.trim() ? message : "turn failed";
        break;
      }
      case "error":
        if (typeof event.message === "string") turn.lastError = event.message;
        break;
    }
  }
  return turn;
}
var LOST = /no rollout found|session not found|thread not found|no thread with id/i;
var SIGN_IN = /\b401\b|unauthori[sz]ed|not logged in|not signed in|missing bearer|please (?:re-?)?(?:log|sign) ?in|codex login|refresh token|token (?:has )?expired|access token/i;
var PLAN_LIMIT = /usage limit|quota exceeded|insufficient_quota|spend limit|spend cap|out of credits|upgrade to (?:plus|pro)/i;
var UNKNOWN_MODEL = /model_not_found|unknown model|invalid model|\bmodel\b[^\n]{0,80}?\b(?:not found|does not exist|not supported|unsupported|not available)/i;
var SANDBOX_REFUSED = /sandbox denied/i;
var SANDBOX_BROKEN = /landlock|seccomp|codex-linux-sandbox|sandbox error/i;
var BAD_SETTINGS = /error loading config|error parsing -c|invalid configuration|unknown configuration key/i;
var REFUSED_LINE = new RegExp(`${FLAGS_REFUSED.source}|invalid value '[^']*' for '--`, "i");
var CodexSession = class {
  constructor(matchId, model, rulebook, name, runner, side = "", timeoutMs = LLM_SERVER_TIMEOUT_MS) {
    this.matchId = matchId;
    this.model = model;
    this.rulebook = rulebook;
    this.name = name;
    this.runner = runner;
    this.side = side;
    this.timeoutMs = timeoutMs;
    this.threadId = null;
    // Codex's session, from the first report's events
    this.closed = false;
    this.queue = Promise.resolve();
    this.dir = null;
    // the session's folder: the rulebook, and "work", empty
    this.running = null;
    console.warn(
      `[llm] ${side} session started: ${model} (the Codex CLI at ${runner.exe}, a session kept by Codex)`
    );
  }
  isAlive() {
    return !this.closed;
  }
  ask(prompt) {
    const answer = this.queue.then(() => this.run(prompt));
    this.queue = answer.catch(() => void 0);
    return answer;
  }
  // The session's folder, made at the first report: the rulebook beside an empty working folder
  folder() {
    if (this.dir) return this.dir;
    const dir = mkdtempSync2(join3(tmpdir2(), "battle-codex-"));
    mkdirSync2(join3(dir, "work"));
    writeFileSync(join3(dir, RULEBOOK_FILE), this.rulebook);
    this.dir = dir;
    return dir;
  }
  removeFolder() {
    if (!this.dir) return;
    try {
      rmSync2(this.dir, { recursive: true, force: true });
      this.dir = null;
    } catch {
    }
  }
  // One run of the Codex CLI: a new session, or the next report of this one
  async once(dir, prompt, threadId) {
    const started = Date.now();
    const out = await runProcess(
      {
        exe: this.runner.exe,
        args: codexArgs(dir, this.name, threadId),
        env: this.runner.env,
        cwd: join3(dir, "work"),
        input: prompt,
        timeoutMs: this.timeoutMs
      },
      (child) => this.running = child
    );
    const turn = readEvents(out.stdout);
    console.warn(
      `[llm] ${this.side} (${this.model}): Codex ran ${((Date.now() - started) / 1e3).toFixed(1)} s, start-up included (${out.spawnError ? `not started: ${out.spawnError}` : out.signal ? `ended by ${out.signal}` : `exit ${out.code}`}; ${threadId ? `session ${threadId.slice(0, 40)}` : "a new session"})`
    );
    if (turn.threadId) this.threadId = turn.threadId;
    return { out, turn };
  }
  async run(prompt) {
    if (this.closed) throw sessionClosed();
    let dir;
    try {
      dir = this.folder();
    } catch (err) {
      throw new LlmError(
        `Codex could not be started: its folder could not be made (${capped(oneLine(String(err.code ?? err)))}).`,
        true,
        true
      );
    }
    const resumed = this.threadId;
    let { out, turn } = await this.once(dir, prompt, resumed);
    if (resumed !== null && !this.closed && this.lost(out, turn, resumed)) {
      console.warn(
        `[llm] ${this.side} (${this.model}): Codex no longer has the session; a new one starts with this report`
      );
      this.threadId = null;
      ({ out, turn } = await this.once(dir, prompt, null));
    }
    if (this.closed) this.removeFolder();
    return this.answer(out, turn);
  }
  lost(out, turn, id) {
    if (out.spawnError || out.timedOut || out.overflow || turn.completed) return false;
    if (out.code === 0 && out.signal === null) return false;
    const said = `${turn.failed ?? ""} ${turn.lastError ?? ""} ${out.stderr}`;
    return LOST.test(said) && said.includes(id);
  }
  answer(out, turn) {
    const { server } = this.runner;
    if (out.spawnError === "ENOENT" || out.spawnError === "EACCES")
      throw new LlmError(
        `Codex could not be started (${out.spawnError}): its program is not there or not runnable; install Codex (${INSTALL}), or fix CODEX_PATH, and restart ${server}.`,
        false,
        true
      );
    if (out.spawnError)
      throw new LlmError(`Codex could not be started (${out.spawnError}).`, true, true);
    if (this.closed) throw new LlmError(SESSION_CLOSED, true, true);
    if (out.timedOut)
      throw new LlmError(
        `Codex did not answer within ${Math.round(this.timeoutMs / 1e3)} s; its process was stopped.`,
        true
      );
    if (out.overflow)
      throw new LlmError(
        "Codex wrote more than 4 MB of output; its process was stopped.",
        true,
        true
      );
    if (turn.failed !== null) throw this.failure(capped(oneLine(this.masked(turn.failed))));
    if (out.code !== 0 || out.signal !== null) {
      const detail = (turn.lastError !== null ? capped(oneLine(this.masked(turn.lastError))) : "") || this.masked(lastWords(out)) || (out.signal ? `ended by ${out.signal}` : `exit ${out.code}`);
      throw this.failure(detail);
    }
    if (!turn.completed)
      throw new LlmError(
        "Codex: the turn did not complete (its events ended before turn.completed); the answer is not used.",
        true,
        true
      );
    const text = withoutThinking(turn.text ?? "");
    if (!text.trim()) throw new LlmError("Codex: the answer was empty.", true, true);
    if (text.length > MAX_ANSWER_CHARS)
      throw new LlmError(
        `Codex: the answer was ${Math.round(text.length / 1e3)} KB of text, more than the ${MAX_ANSWER_CHARS / 1e3} KB an answer may have.`,
        true,
        true
      );
    const usage = turn.usage ?? {};
    return {
      text,
      meta: {
        costUsd: null,
        // Codex reports none
        inputTokens: num(usage.input_tokens),
        outputTokens: num(usage.output_tokens),
        cacheReadTokens: num(usage.cached_input_tokens),
        cacheWriteTokens: num(usage.cache_write_input_tokens),
        apiMs: null,
        turns: 1,
        modelIds: this.name === null ? [] : [this.name]
      }
    };
  }
  // A failed turn or run, by what Codex's text says (already cut to 300 characters)
  failure(detail) {
    const { server } = this.runner;
    if (REFUSED_LINE.test(detail))
      return new LlmError(
        `The installed Codex does not accept the command line the bridge gives it (an older or newer version?): ${detail}`,
        false,
        true
      );
    if (BAD_SETTINGS.test(detail))
      return new LlmError(
        `The installed Codex refused the settings the bridge gives it (another version?): ${detail}`,
        false,
        true
      );
    if (SIGN_IN.test(detail))
      return new LlmError(
        `Codex is not signed in on this computer, or its sign-in has expired (${detail}). Run codex once in a terminal and sign in (codex login), then start the match again.`,
        false,
        true
      );
    if (PLAN_LIMIT.test(detail))
      return new LlmError(
        `Codex: a limit of its plan or key was reached (${detail}).`,
        false,
        true
      );
    if (UNKNOWN_MODEL.test(detail))
      return new LlmError(
        `Codex cannot use ${this.name === null ? "its default model" : `the model "${this.name}"`} (${detail}). Choose another model.`,
        false,
        true
      );
    if (SANDBOX_REFUSED.test(detail))
      return new LlmError(
        `Codex's read-only sandbox refused what the model tried to do (${detail}).`,
        true,
        true
      );
    if (SANDBOX_BROKEN.test(detail))
      return new LlmError(
        `Codex's sandbox cannot run here (${detail}); see Codex's own documentation on its sandbox, then restart ${server}.`,
        false,
        true
      );
    return new LlmError(
      `Codex failed (${detail}). If it keeps failing: if Codex is not signed in, run codex once in a terminal and sign in (codex login).`,
      true,
      true
    );
  }
  // The keys set for Codex on purpose, out of its text
  masked(text) {
    let result = text;
    for (const key of this.runner.keys) result = result.split(key).join("\u2026");
    return result;
  }
  // Replaced by a new match or model, or the server is closing: a running Codex is stopped (with
  // every process it started) and the session's folder removed; a request still waiting fails with
  // "session was closed". Codex's own session files stay (they are its, in CODEX_HOME).
  close() {
    this.closed = true;
    if (this.running) stopTree(this.running);
    this.removeFolder();
  }
};

// server/geminiSession.ts
var GEMINI_URL = "https://generativelanguage.googleapis.com/v1/interactions";
var setGeminiKey = (server) => `Set GEMINI_API_KEY in .env.local and restart ${server}.`;
function geminiProvider(key, server = DEV_SERVER) {
  const k = key.trim();
  if (!k) return setGeminiKey(server);
  const problem = keyProblem("GEMINI_API_KEY", k, server);
  if (problem) return problem;
  return (id) => ({ id, key: k, server });
}
var Lost = class extends Error {
};
var record = (v) => v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
var GeminiSession = class {
  constructor(matchId, model, systemPrompt, api, side = "") {
    this.matchId = matchId;
    this.model = model;
    this.systemPrompt = systemPrompt;
    this.api = api;
    this.side = side;
    this.previous = null;
    // the last completed interaction of this conversation
    this.closed = false;
    this.queue = Promise.resolve();
    this.abort = new AbortController();
    console.warn(
      `[llm] ${side} session started: ${api.id} (Gemini Interactions API, the conversation kept by Google)`
    );
  }
  isAlive() {
    return !this.closed;
  }
  ask(prompt) {
    const answer = this.queue.then(() => this.send(prompt));
    this.queue = answer.catch(() => void 0);
    return answer;
  }
  async send(prompt) {
    if (this.closed) throw sessionClosed();
    try {
      return await this.interact(prompt, this.previous);
    } catch (err) {
      if (!(err instanceof Lost)) throw err;
      console.warn(
        `[llm] ${this.side} (${this.model}): the conversation Google kept was lost (${err.message}); a new one starts with this report`
      );
      this.previous = null;
      return this.interact(prompt, null);
    }
  }
  async interact(prompt, previous) {
    const { api } = this;
    const started = Date.now();
    let res;
    try {
      res = await fetch(GEMINI_URL, {
        method: "POST",
        signal: this.abort.signal,
        // Not followed: the rulebook and the report would go to whatever address it names
        redirect: "manual",
        headers: { "x-goog-api-key": api.key, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: api.id,
          input: prompt,
          system_instruction: this.systemPrompt,
          ...previous === null ? {} : { previous_interaction_id: previous }
        })
      });
    } catch (err) {
      throw new LlmError(
        this.closed ? SESSION_CLOSED : `Gemini could not be reached: ${capped(errorText(err).split(api.key).join("\u2026"))}`,
        true,
        true
      );
    }
    if (res.type === "opaqueredirect" || res.status >= 300 && res.status < 400) {
      res.body?.cancel().catch(() => void 0);
      throw new LlmError(
        `Gemini answered with a redirect (HTTP ${res.status}), which is not followed.`,
        false,
        true
      );
    }
    const body = record(await res.json().catch(() => null));
    if (this.closed) throw new LlmError(SESSION_CLOSED, true, true);
    const error = body?.error;
    const message = typeof error === "string" ? error : record(error)?.message;
    const detail = capped(typeof message === "string" ? message : "");
    if (!res.ok) {
      if (previous !== null && (res.status === 404 || res.status === 400 && /previous_interaction|interaction[^.]*(?:not found|expired|does not exist)/i.test(
        detail
      )))
        throw new Lost(`HTTP ${res.status}`);
      const lasting = [400, 401, 403, 404].includes(res.status);
      const hint = res.status === 401 || res.status === 403 ? ` Check GEMINI_API_KEY in .env.local and restart ${api.server}.` : res.status === 404 ? ` The Gemini API may not know the model "${api.id}".` : res.status === 429 ? " The key reached a rate limit or its quota (the free tier has low limits)." : "";
      throw new LlmError(
        `Gemini: ${detail || `HTTP ${res.status}`} (HTTP ${res.status}).${hint}`,
        !lasting,
        true
      );
    }
    const status = body?.status;
    if (status !== "completed") {
      const failure = Array.isArray(body?.errors) ? body.errors.map((e) => record(e)?.message).filter((m) => typeof m === "string") : [];
      throw new LlmError(
        status === "incomplete" ? "Gemini: the answer was cut off at the model's output limit." : `Gemini: the interaction ended as ${capped(String(status ?? "unknown"))}${failure.length ? ` (${capped(failure.join("; "))})` : ""}.`,
        true,
        true
      );
    }
    const steps = Array.isArray(body?.steps) ? body.steps : [];
    const text = steps.map(record).filter((s) => s?.type === "model_output" && Array.isArray(s.content)).flatMap((s) => s.content).map(record).filter((c) => c?.type === "text" && typeof c.text === "string").map((c) => c.text).join("");
    if (!text.trim()) throw new LlmError("Gemini: the answer was empty.", true, true);
    if (text.length > MAX_ANSWER_CHARS)
      throw new LlmError(
        `Gemini: the answer was ${Math.round(text.length / 1e3)} KB of text, more than the ${MAX_ANSWER_CHARS / 1e3} KB an answer may have.`,
        true,
        true
      );
    this.previous = typeof body?.id === "string" && body.id ? body.id : null;
    const usage = record(body?.usage) ?? {};
    return {
      text,
      meta: {
        costUsd: null,
        // the API reports none
        inputTokens: num(usage.total_input_tokens),
        outputTokens: num(usage.total_output_tokens),
        cacheReadTokens: num(usage.total_cached_tokens),
        cacheWriteTokens: null,
        apiMs: Date.now() - started,
        turns: 1,
        modelIds: [typeof body?.model === "string" ? body.model : api.id]
      }
    };
  }
  close() {
    this.closed = true;
    this.abort.abort();
  }
};

// server/llmEndpoint.ts
function defaultModel(value) {
  return CLAUDE_MODELS.includes(value ?? "") ? value : "sonnet";
}
function maxBudget(value) {
  return Number(value) || 5;
}
var sessions = /* @__PURE__ */ new Map();
var MAX_BODY_BYTES = 1e6;
var BODY_TIMEOUT_MS = 3e4;
var SIDES = ["west", "east"];
var MAX_BODIES_IN_FLIGHT = 8;
var BUSY_RETRY_AFTER_S = 5;
var REPLACED_LOG_MS = 6e4;
var TooLarge = class extends Error {
};
var TooSlow = class extends Error {
};
var ClientGone = class extends Error {
};
function readBody(req) {
  return new Promise((resolve3, reject) => {
    if (Number(req.headers["content-length"]) > MAX_BODY_BYTES) return reject(new TooLarge());
    const chunks = [];
    let size = 0;
    let done = false;
    const finish = (err) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      if (err) reject(err);
      else resolve3(Buffer.concat(chunks, size).toString("utf8"));
    };
    const timer = setTimeout(() => finish(new TooSlow()), BODY_TIMEOUT_MS);
    req.on("data", (data) => {
      if (done) return;
      const chunk = typeof data === "string" ? Buffer.from(data) : data;
      size += chunk.length;
      if (size > MAX_BODY_BYTES) finish(new TooLarge());
      else chunks.push(chunk);
    });
    req.on("end", () => finish(null));
    req.on("error", (err) => finish(err));
    req.on("close", () => finish(new Error("the request was closed before its body ended")));
  });
}
var REFUSED_BODY_MS = 1e3;
function refuseBody(req, res, status, error, headers = {}) {
  let sent = false;
  const answer = () => {
    if (sent) return;
    sent = true;
    clearTimeout(timer);
    for (const [name, value] of Object.entries(headers)) res.setHeader(name, value);
    res.setHeader("Connection", "close");
    send(res, status, { error });
  };
  const timer = setTimeout(answer, REFUSED_BODY_MS);
  if (req.complete || req.readableEnded) return answer();
  req.on("end", answer);
  req.on("close", answer);
  req.resume();
}
function withTimeout(promise, ms) {
  return new Promise((resolve3, reject) => {
    const timer = setTimeout(() => reject(new Error(`no answer within ${ms / 1e3} s`)), ms);
    promise.then(
      (v) => {
        clearTimeout(timer);
        resolve3(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      }
    );
  });
}
function clientGone(res) {
  let onClose = () => {
  };
  const gone = new Promise((_resolve, reject) => {
    onClose = () => {
      if (!res.writableEnded) reject(new ClientGone("the browser closed the request"));
    };
    res.on("close", onClose);
  });
  gone.catch(() => void 0);
  return { gone, done: () => res.off("close", onClose) };
}
function isText(value) {
  return typeof value === "string" && value !== "";
}
function send(res, status, body) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json");
  res.end(JSON.stringify(body));
}
var cliOff = (server) => `Command-line tools are turned off here (CLI_TOOLS=off); remove the setting and restart ${server}.`;
function llmEndpoint(env, options) {
  const server = options.server ?? DEV_SERVER;
  const DEFAULT_MODEL = defaultModel(env.LLM_MODEL ?? process.env.LLM_MODEL);
  const MAX_BUDGET_USD = maxBudget(env.LLM_MAX_BUDGET_USD ?? process.env.LLM_MAX_BUDGET_USD);
  const openRouter = openRouterProvider(
    env.OPENROUTER_API_KEY ?? process.env.OPENROUTER_API_KEY ?? "",
    MAX_BUDGET_USD,
    server
  );
  const local = localProvider(
    env.LOCAL_LLM_URL ?? process.env.LOCAL_LLM_URL,
    env.LOCAL_LLM_KEY ?? process.env.LOCAL_LLM_KEY ?? "",
    env.LOCAL_LLM_HISTORY_TURNS ?? process.env.LOCAL_LLM_HISTORY_TURNS,
    MAX_BUDGET_USD,
    server
  );
  const vars = { ...process.env, ...env };
  const cli = cliConfig(vars);
  for (const warning of cli.warnings) console.warn(`[llm] ${warning}`);
  const gemini = geminiProvider(vars.GEMINI_API_KEY ?? "", server);
  const codex = () => codexRunner(vars, server);
  const { query } = options;
  const chatApi = (model) => {
    const routerId = openRouterId(model);
    if (routerId !== null)
      return typeof openRouter === "string" ? openRouter : openRouter(routerId);
    const localId = localModelId(model);
    if (localId !== null) return typeof local === "string" ? local : local(localId);
    return null;
  };
  const openerFor = async (model) => {
    const toolName = cliToolOf(model);
    if (toolName !== null) {
      const tool = cli.tools.get(toolName);
      if (!tool) return { status: 400, error: `unknown model ${model.slice(0, 80)}` };
      if (!cli.enabled) return { status: 500, error: cliOff(server), retryable: false };
      return (matchId, system, side) => new CliSession(matchId, model, system, tool, cli, side);
    }
    const codexId = codexModel(model);
    if (codexId !== null) {
      const runner = codex();
      if (typeof runner === "string") return { status: 500, error: runner, retryable: false };
      return (matchId, system, side) => new CodexSession(matchId, model, system, codexId.model, runner, side);
    }
    const geminiId = geminiModelId(model);
    if (geminiId !== null) {
      if (typeof gemini === "string") return { status: 500, error: gemini, retryable: false };
      return (matchId, system, side) => new GeminiSession(matchId, model, system, gemini(geminiId), side);
    }
    const chat = chatApi(model);
    if (typeof chat === "string") return { status: 500, error: chat, retryable: false };
    if (chat) return (matchId, system, side) => new ChatSession(matchId, model, system, chat, side);
    if (typeof query === "string") return { status: 500, error: query, retryable: false };
    return (matchId, system, side) => new ClaudeSession(query, matchId, model, system, MAX_BUDGET_USD, side);
  };
  let reading = 0;
  const replaced = /* @__PURE__ */ new Map();
  const handle = async (req, res) => {
    if (req.method !== "POST") return send(res, 405, { error: "POST only" });
    let body;
    if (reading >= MAX_BODIES_IN_FLIGHT)
      return refuseBody(req, res, 503, "too many requests at once", {
        "Retry-After": String(BUSY_RETRY_AFTER_S)
      });
    reading++;
    try {
      body = JSON.parse(await readBody(req).finally(() => reading--));
    } catch (err) {
      if (err instanceof TooLarge) return refuseBody(req, res, 413, "request too large");
      if (err instanceof TooSlow)
        return refuseBody(
          req,
          res,
          408,
          `the body did not come within ${BODY_TIMEOUT_MS / 1e3} s`
        );
      return send(res, 400, { error: "body must be JSON" });
    }
    const { side, matchId, system, prompt, model: requested } = body ?? {};
    if (!isText(side) || !isText(matchId) || !isText(system) || !isText(prompt))
      return send(res, 400, { error: "side, matchId, system and prompt must be text" });
    if (!SIDES.includes(side)) return send(res, 400, { error: "side must be west or east" });
    try {
      if (requested !== void 0 && typeof requested !== "string")
        return send(res, 400, { error: "model must be text" });
      const model = requested ?? DEFAULT_MODEL;
      if (!isLlmModel(model))
        return send(res, 400, { error: `unknown model ${model.slice(0, 80)}` });
      const open = await openerFor(model);
      if (typeof open !== "function")
        return send(
          res,
          open.status,
          open.retryable === void 0 ? { error: open.error } : { error: open.error, retryable: open.retryable }
        );
      let session = sessions.get(side);
      if (!session || !session.isAlive() || session.matchId !== matchId || session.model !== model) {
        if (session?.isAlive() && session.matchId !== matchId) {
          const last = replaced.get(side);
          let loggedAt = last?.loggedAt ?? -Infinity;
          const now = Date.now();
          if (last?.matchId === matchId && now - loggedAt >= REPLACED_LOG_MS) {
            console.warn(
              `[llm] ${side}: two matches use this side at once (two tabs?); each request starts a new session and the LLM loses the match's conversation`
            );
            loggedAt = now;
          }
          replaced.set(side, { matchId: session.matchId, loggedAt });
        }
        session?.close();
        session = open(matchId, system, side);
        sessions.set(side, session);
      }
      const started = Date.now();
      let answer;
      const client = clientGone(res);
      try {
        answer = await Promise.race([
          withTimeout(session.ask(prompt), LLM_SERVER_TIMEOUT_MS),
          client.gone
        ]);
      } catch (err) {
        if (err instanceof ClientGone) {
          console.warn(`[llm] ${side} (${model}): ${err.message}; its answer is dropped`);
          return;
        }
        if (!(err instanceof LlmError && err.fromResult)) {
          session.close();
          if (sessions.get(side) === session) sessions.delete(side);
        }
        throw err;
      } finally {
        client.done();
      }
      console.warn(
        `[llm] ${side} (${model}): answered in ${((Date.now() - started) / 1e3).toFixed(1)} s (API ${answer.meta.apiMs === null ? "?" : (answer.meta.apiMs / 1e3).toFixed(1)} s)`
      );
      send(res, 200, {
        text: answer.text,
        latencyMs: Date.now() - started,
        model,
        ...answer.meta
      });
    } catch (err) {
      console.warn(`[llm] ${side} (${String(requested ?? DEFAULT_MODEL)}): ${errorText(err)}`);
      send(res, 500, {
        error: errorText(err),
        retryable: err instanceof LlmError ? err.retryable : true
      });
    }
  };
  const close = () => {
    for (const s of sessions.values()) s.close();
    sessions.clear();
  };
  const ways = async () => {
    const runner = codex();
    return {
      codex: typeof runner === "string" ? { available: false, reason: runner } : { available: true },
      gemini: typeof gemini !== "string",
      custom: cliStatus(cli)
    };
  };
  return { handle, close, ways };
}

// server/bridgeClaude.ts
var CLAUDE_BAD_KEY = "ANTHROPIC_API_KEY has characters a header cannot carry (a line break or a pasted quote?); fix it and restart the bridge.";
var SDK_MISSING = "Claude models need the Claude Agent SDK, which could not be loaded where the bridge runs: start the bridge with npx (it installs the SDK) or from a clone of the repository (npm install, then npm run bridge).";
var RANKED_ABOVE_KEY = [
  "CLAUDE_CODE_USE_BEDROCK",
  "CLAUDE_CODE_USE_VERTEX",
  "CLAUDE_CODE_USE_FOUNDRY",
  "ANTHROPIC_AUTH_TOKEN",
  "CLAUDE_CODE_OAUTH_TOKEN"
];
var OTHER_KEYS = [
  "OPENROUTER_API_KEY",
  "LOCAL_LLM_KEY",
  "GEMINI_API_KEY",
  "CODEX_API_KEY",
  "OPENAI_API_KEY",
  "TYPESAFE_API_KEY",
  "SUBQ_API_KEY",
  "AI_PASSWORD"
];
function claudeWay(sdkQuery, key) {
  const k = (key ?? "").trim();
  if (!sdkQuery) return SDK_MISSING;
  if (k && !/^[\x21-\x7e]+$/.test(k)) return CLAUDE_BAD_KEY;
  return k ? "key" : "sign-in";
}
function bridgeClaude(sdkQuery, key) {
  const way = claudeWay(sdkQuery, key);
  if (way !== "key" && way !== "sign-in") return way;
  return withEnvironment(sdkQuery, way === "key" ? (key ?? "").trim() : null);
}
function withEnvironment(sdkQuery, key) {
  return (params) => {
    const env = { ...params.options?.env ?? process.env };
    for (const name of OTHER_KEYS) delete env[name];
    if (key) {
      for (const name of RANKED_ABOVE_KEY) delete env[name];
      env.ANTHROPIC_API_KEY = key;
    } else delete env.ANTHROPIC_API_KEY;
    return sdkQuery({ ...params, options: { ...params.options, env } });
  };
}

// server/bridge.ts
var BRIDGE_VERSION = "1.1.0";
var DEMO_URL = "https://aakin21.github.io/2D-Battle-Simulation/";
var LOOPBACK = "127.0.0.1";
var BRIDGE = "the bridge";
var SETTINGS = [
  "LOCAL_LLM_URL",
  "LOCAL_LLM_KEY",
  "LOCAL_LLM_HISTORY_TURNS",
  "LLM_MODEL",
  "LLM_MAX_BUDGET_USD",
  "OPENROUTER_API_KEY",
  "ANTHROPIC_API_KEY",
  "GEMINI_API_KEY",
  "CODEX_API_KEY",
  "OPENAI_API_KEY",
  "CODEX_PATH",
  "AI_ALLOWED_ORIGINS",
  "BRIDGE_PORT",
  "BRIDGE_OPEN",
  "CLI_TOOLS",
  "CLI_HISTORY_TURNS"
];
var CLI_SETTING = /^CLI_TOOL_[A-Z0-9_]+$/;
function loadSettings(dir, environment = process.env) {
  const path = join4(dir, ".env.local");
  let fromFile = {};
  let file = null;
  let problem = null;
  let text = null;
  try {
    text = readFileSync(path, "utf8");
  } catch (err) {
    const code = err.code;
    if (code !== "ENOENT") problem = `.env.local could not be read (${String(code)})`;
  }
  if (text !== null) {
    if (typeof util.parseEnv !== "function")
      problem = "this Node.js cannot read .env.local (Node 20.12 or newer can)";
    else {
      fromFile = util.parseEnv(text);
      file = path;
    }
  }
  const env = {};
  const cliNames = [...Object.keys(fromFile), ...Object.keys(environment)].filter(
    (n) => CLI_SETTING.test(n)
  );
  for (const name of /* @__PURE__ */ new Set([...SETTINGS, ...cliNames])) {
    const value = environment[name] ?? fromFile[name];
    if (value !== void 0) env[name] = value;
  }
  return { env, file, problem };
}
function parsePort(value) {
  const v = value.trim();
  return /^\d{1,5}$/.test(v) && Number(v) <= 65535 ? Number(v) : null;
}
var MODELS_TIMEOUT_MS = 2e3;
var MAX_MODELS_BYTES = 1e6;
var MAX_MODELS = 200;
async function listLocalModels(local, key, timeoutMs = MODELS_TIMEOUT_MS) {
  try {
    const res = await fetch(local.modelsUrl, {
      headers: key ? { Authorization: `Bearer ${key}` } : {},
      redirect: "manual",
      signal: AbortSignal.timeout(timeoutMs)
    });
    if (res.status !== 200 || !res.body) {
      res.body?.cancel().catch(() => void 0);
      return null;
    }
    const chunks = [];
    let size = 0;
    const reader = res.body.getReader();
    for (let r = await reader.read(); !r.done; r = await reader.read()) {
      size += r.value.length;
      if (size > MAX_MODELS_BYTES) {
        reader.cancel().catch(() => void 0);
        return null;
      }
      chunks.push(r.value);
    }
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!Array.isArray(body?.data)) return null;
    const ids = body.data.map((m) => m?.id).filter((id) => typeof id === "string" && isLocalModelName(id));
    return [...new Set(ids)].slice(0, MAX_MODELS);
  } catch {
    return null;
  }
}
function llmStatus(env, endpoint, claude, server) {
  const local = localServer(env.LOCAL_LLM_URL, server);
  const localKey = (env.LOCAL_LLM_KEY ?? "").trim();
  const keyUsable = /^[\x21-\x7e]*$/.test(localKey);
  const openrouter = typeof openRouterProvider(env.OPENROUTER_API_KEY ?? "", 0, server) !== "string";
  return async () => {
    const ways = await endpoint.ways();
    return {
      claude,
      codex: ways.codex,
      gemini: ways.gemini,
      local: typeof local === "string" ? { url: null, models: null } : {
        url: local.origin,
        models: keyUsable ? await listLocalModels(local, localKey) : null
      },
      openrouter,
      custom: ways.custom
    };
  };
}
var tacticalMissing = (name) => `${name} is not available through the AI bridge, which serves the LLM only: choose "LLM" for this side in the Battle menu.`;
function startBridge(options) {
  const { env } = options;
  const claude = bridgeClaude(options.sdkQuery, env.ANTHROPIC_API_KEY);
  const endpoint = llmEndpoint(env, { query: claude, server: BRIDGE });
  const guard = aiAccess(
    env.AI_ALLOWED_ORIGINS === void 0 ? {} : { AI_ALLOWED_ORIGINS: env.AI_ALLOWED_ORIGINS },
    { loopbackOrigins: true }
  );
  const runs = llmStatus(env, endpoint, typeof claude === "function", BRIDGE);
  const status = async () => ({
    bridge: true,
    version: BRIDGE_VERSION,
    llm: await runs()
  });
  let hosts = /* @__PURE__ */ new Set();
  const route = (req, res) => {
    const path = (req.url ?? "").split("?")[0];
    if (path === "/api/llm") {
      endpoint.handle(req, res).catch((err) => {
        console.warn(
          `[bridge] /api/llm failed: ${err instanceof Error ? err.message : String(err)}`
        );
        if (!res.headersSent) send(res, 500, { error: "the bridge failed to answer" });
        else res.destroy();
      });
      return;
    }
    if (path === "/api/bridge") {
      if (req.method !== "GET") return refuseBody(req, res, 405, "GET only", { Allow: "GET" });
      void status().then((s) => {
        res.setHeader("Cache-Control", "no-store");
        send(res, 200, s);
      });
      return;
    }
    if (path === "/api/jev" || path === "/api/snap") {
      if (req.method !== "POST")
        return refuseBody(req, res, 405, "only POST is accepted", { Allow: "POST" });
      return refuseBody(req, res, 404, tacticalMissing(path === "/api/jev" ? "Jev" : "SubQ Snap"));
    }
    refuseBody(req, res, 404, "not found");
  };
  const server = http.createServer((req, res) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    if (!hosts.has(req.headers.host ?? ""))
      return deny(res, 403, "the bridge answers only requests addressed to localhost or 127.0.0.1");
    guard(req, res, () => route(req, res));
  });
  return new Promise((resolve3, reject) => {
    server.once("error", reject);
    server.listen({ port: options.port, host: LOOPBACK, exclusive: true }, () => {
      server.off("error", reject);
      const port = server.address().port;
      const names = ["localhost", "127.0.0.1", "[::1]"];
      hosts = /* @__PURE__ */ new Set([...names.map((n) => `${n}:${port}`), ...port === 80 ? names : []]);
      resolve3({
        port,
        url: `http://${LOOPBACK}:${port}`,
        status,
        close: () => new Promise((done) => {
          endpoint.close();
          server.close(() => done());
          server.closeAllConnections();
        })
      });
    });
  });
}
function demoLink(env, bridgeUrl) {
  return allowedOrigins(env).has(new URL(DEMO_URL).origin) ? `${DEMO_URL}?ai=${bridgeUrl}` : null;
}

// server/bridgeCli.ts
var USAGE = `Usage: node ai-bridge.mjs [--port <number>] [--no-open]

Serves the LLM endpoint of the 2D Battle Simulation on this computer only, so that the online
demo can use what you have here: a local server such as Ollama, Claude (your Claude Code
sign-in, or your Anthropic API key), Codex (your Codex sign-in), Gemini with your Gemini API
key, OpenRouter with your key. When it has started it opens the demo in your browser, connected
to it.
Settings come from the environment and from .env.local in the current folder:
  ${SETTINGS.join(", ")},
  and CLI_TOOL_<NAME> (a command of your own).
--port (or BRIDGE_PORT) chooses the port, ${DEFAULT_BRIDGE_PORT} by default (0: any free port).
--no-open (or BRIDGE_OPEN=0) does not open the browser.`;
async function loadSdk() {
  try {
    const sdk = await import("@anthropic-ai/claude-agent-sdk");
    if (typeof sdk.query === "function") return sdk.query;
  } catch {
  }
  return null;
}
function stop(message, code = 1) {
  console.error(`AI bridge: ${message}`);
  process.exit(code);
}
function readArgs(args) {
  let port;
  let open = true;
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === "--help" || arg === "-h") return { help: true, open: false };
    if (arg === "--port") port = args[++i] ?? "";
    else if (arg.startsWith("--port=")) port = arg.slice("--port=".length);
    else if (arg === "--no-open") open = false;
    else stop(`unknown option ${JSON.stringify(arg.slice(0, 40))}

${USAGE}`, 2);
  }
  return { help: false, port, open };
}
var openSetting = (value) => !/^(off|0|false|no)$/i.test((value ?? "").trim());
var KEYS = [
  "OPENROUTER_API_KEY",
  "LOCAL_LLM_KEY",
  "ANTHROPIC_API_KEY",
  "GEMINI_API_KEY",
  "CODEX_API_KEY",
  "OPENAI_API_KEY",
  "TYPESAFE_API_KEY",
  "SUBQ_API_KEY",
  "AI_PASSWORD"
];
function openBrowser(url) {
  const pathEnv = process.env.PATH ?? "";
  const windows = process.platform === "win32";
  const name = process.platform === "darwin" ? "open" : windows ? "cmd" : "xdg-open";
  const exe = locate(name, null, pathEnv);
  if (typeof exe !== "string") return Promise.resolve(false);
  const env = { ...process.env };
  for (const key of KEYS) delete env[key];
  return new Promise((done) => {
    try {
      const child = spawn2(exe, windows ? ["/d", "/c", "start", "", url] : [url], {
        env,
        stdio: "ignore",
        detached: true,
        windowsHide: true,
        shell: false
      });
      child.once("error", () => done(false));
      child.once("spawn", () => {
        child.unref();
        done(true);
      });
    } catch {
      done(false);
    }
  });
}
function portOf(given, settings) {
  const text = given ?? settings.env.BRIDGE_PORT ?? String(DEFAULT_BRIDGE_PORT);
  const port = parsePort(text);
  if (port === null)
    stop(
      `the port must be a number from 0 to 65535 (${given === void 0 ? "BRIDGE_PORT" : "--port"} is ${JSON.stringify(text.slice(0, 20))}).`,
      2
    );
  return port;
}
var MODELS_SHOWN = 8;
function report(bridge, status, settings, cwd, sdkQuery, opened) {
  const { env } = settings;
  const { llm } = status;
  const lines = [`2D Battle Simulation AI bridge ${status.version}`];
  lines.push(`Listening on ${bridge.url} (this computer only)`, "");
  const local = localServer(env.LOCAL_LLM_URL, "the bridge");
  let localLine;
  if (typeof local === "string") localLine = local;
  else if (llm.local.models === null)
    localLine = `${local.origin} does not answer: start Ollama (or your local server), or set LOCAL_LLM_URL.`;
  else if (llm.local.models.length === 0)
    localLine = `${local.origin} answers but has no models (with Ollama: ollama pull <model>).`;
  else {
    const shown = llm.local.models.slice(0, MODELS_SHOWN).join(", ");
    const more = llm.local.models.length - MODELS_SHOWN;
    localLine = `${local.origin}: ${llm.local.models.length} model${llm.local.models.length === 1 ? "" : "s"} (${shown}${more > 0 ? `, and ${more} more` : ""})`;
  }
  if (!/^[\x21-\x7e]*$/.test((env.LOCAL_LLM_KEY ?? "").trim()))
    localLine += " LOCAL_LLM_KEY has characters a header cannot carry; fix it.";
  lines.push(`  Local models   ${localLine}`);
  const claude = claudeWay(sdkQuery, env.ANTHROPIC_API_KEY);
  lines.push(
    `  Claude         ${claude === "key" ? "with your Anthropic API key (ANTHROPIC_API_KEY), billed to its account; a session stops at LLM_MAX_BUDGET_USD of estimated spend" : claude === "sign-in" ? "your Claude Code sign-in on this computer (not signed in: run claude once and sign in)" : `off: ${claude}`}`
  );
  const codexKey = (env.CODEX_API_KEY ?? "").trim() ? ", with CODEX_API_KEY" : "";
  lines.push(
    `  Codex          ${llm.codex.available ? `found: your Codex sign-in on this computer${codexKey} (not signed in: run codex once and sign in)` : llm.codex.reason === codexMissing("the bridge") ? "not found (install it and sign in: npm install -g @openai/codex, then codex login)" : `off: ${llm.codex.reason ?? ""}`}`
  );
  const geminiKey = (env.GEMINI_API_KEY ?? "").trim();
  lines.push(
    `  Gemini         ${llm.gemini ? "key set (GEMINI_API_KEY)" : geminiKey ? "GEMINI_API_KEY has characters a header cannot carry; fix it." : "no key (optional: GEMINI_API_KEY in .env.local)"}`
  );
  const routerKey = (env.OPENROUTER_API_KEY ?? "").trim();
  lines.push(
    `  OpenRouter     ${llm.openrouter ? "key set (OPENROUTER_API_KEY)" : routerKey ? "OPENROUTER_API_KEY has characters a header cannot carry; fix it." : "no key (optional: OPENROUTER_API_KEY in .env.local)"}`
  );
  if (!cliEnabled(env.CLI_TOOLS)) lines.push("  Own commands   off (CLI_TOOLS=off)");
  else if (llm.custom.length > 0)
    lines.push(
      `  Own commands   ${llm.custom.map((t) => `${t.id} ${t.available ? "found" : "not found"}`).join(", ")}`
    );
  const where = settings.file ? `.env.local in ${cwd} and the environment` : `the environment${settings.problem ? ` (${settings.problem})` : ` (no .env.local in ${cwd})`}`;
  lines.push(`  Settings       ${where}`);
  lines.push(`  Allowed sites  ${[...allowedOrigins(env)].join(", ")} and pages on this computer`);
  lines.push("");
  const link = demoLink(env, bridge.url);
  if (link && opened) lines.push("Opened the demo in your browser, connected to this bridge.");
  else if (link && opened === false) lines.push("Could not open a browser here.");
  if (link)
    lines.push(
      `${opened ? "In another browser, open" : "Open the demo with this bridge"}:`,
      `  ${link}`
    );
  else lines.push(`Open your site with ?ai=${bridge.url} added to its address.`);
  lines.push(
    "",
    "The first time, the browser asks whether the site may reach your computer: allow it.",
    "Press Ctrl+C to stop the bridge."
  );
  return lines.join("\n");
}
async function main() {
  const args = readArgs(process.argv.slice(2));
  if (args.help) {
    console.log(USAGE);
    return;
  }
  const cwd = process.cwd();
  const settings = loadSettings(cwd);
  const port = portOf(args.port, settings);
  const sdkQuery = await loadSdk();
  let bridge;
  try {
    bridge = await startBridge({ port, env: settings.env, sdkQuery });
  } catch (err) {
    const code = err.code;
    if (code === "EADDRINUSE")
      stop(
        `port ${port} on 127.0.0.1 is already in use (is the bridge already running?). Start it on another port with --port <number> or BRIDGE_PORT=<number>.`
      );
    if (code === "EACCES")
      stop(`port ${port} cannot be used without administrator rights; choose one above 1023.`);
    stop(`could not start: ${err instanceof Error ? err.message : String(err)}`);
  }
  const link = demoLink(settings.env, bridge.url);
  const opened = link && args.open && openSetting(settings.env.BRIDGE_OPEN) ? await openBrowser(link) : null;
  console.log(report(bridge, await bridge.status(), settings, cwd, sdkQuery, opened));
  const quit = () => void bridge.close().then(() => process.exit(0));
  process.once("SIGINT", quit);
  process.once("SIGTERM", quit);
}
void main();
